import json
import boto3
import pickle
from boto3.dynamodb.conditions import Key, Attr

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('rekognition')
print 'Loading function'
# todo:check face_id in dynamo.If not registered,guidance with polly
# send registering mail after polly guidance
def lambda_handler(event, context):
    s3 = boto3.client('s3')
    with open('/tmp/obj', 'wb') as data:
        s3.download_fileobj('smart-recognition', 'result_pickle', data)
    with open('/tmp/obj', 'r') as f:
        rekognition_result  = pickle.load(f)
    face_id = rekognition_result['FaceMatches'][0]['Face']['FaceId']
    try:
        response = table.get_item(
            Key={
                'face_id': face_id
            }
        )
    except ClientError as e:
        print(e.response['Error']['Message'])
    slack_name = response['Item']['slack_name']
    with open('/tmp/slack_name_dump', 'w') as f:
        pickle.dump(slack_name, f)
    s3 = boto3.resource('s3')
    s3.meta.client.upload_file('/tmp/slack_name_dump', 'smart-recognition', 'slack_name')
    return response
